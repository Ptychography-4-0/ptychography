clear; clc; close all;

set(0,'DefaultTextInterpreter','latex')
set(0,'DefaultLegendInterpreter','latex')
set(0,'DefaultAxesTickLabelInterpreter','latex')
set(0,'DefaultLegendFontSize',20)
set(0,'DefaultTextFontSize',20)
set(0,'DefaultAxesFontSize',16)
set(0,'DefaultLineLineWidth',2);

% Success rate and average error for different sigmas

% parameters for success rate
runs = 5;
success_constant = 0.05;

% parameters point cloud
Nsp = 25;                           % number of subspaces
M = 100;                            % number of points in point cloud (times Nsp)
ds = 1;                             % ds-dimensional subspace in Rd
noise = 0.1;
MOutliers = 0;

%% KV-CBO parameters
d = 10;
p = 2; 
delta = 0; 
energy_functional = @Energy_Class.RobustSubspaceDetection; 

% variable Parameters
sigma_range = [3 2 1]; 

% fix parameters
parameters = struct;
parameters.d = d;
parameters.alpha = 2e15;
parameters.alphamax = 2e15;                                % comment this ligne out to have a constant alpha
parameters.mode = 2;                                       % 1 = isotropic, 2 = anisotropic
parameters.N = 30;                                         % number of particles
parameters.N2 = parameters.N;                              % number of particles to be evolved (randomly chosen
parameters.N3 = parameters.N;                              % number of particles to compute Valpha (randomly chosen)
parameters.lambda = 1;
parameters.dt = 0.25;
parameters.T = 10000;                                      % maximal number of iterations
parameters.time_limit = 10;                                % time limit in seconds
parameters.epsilon = 1e-4;                                 % for stopping condition
parameters.mu = 1;                                         % parameter mu to drop particles
parameters.Nmin = 250;                                     % minimal number of particles
parameters.tau = 1.2; parameters.eta = 2;                  % parameters to adaptively change the sigma
parameters.l = 25;                                         % particles, sigma and alpha are updated every l-th iteratio
parameters.verbose = 0;

% auxiliary variables
summary = []; 
total_time = 0;
srateSigma = zeros(1, size(sigma_range, 2));
count_consensus = zeros(1, size(sigma_range, 2));
average_error = zeros(size(sigma_range,2),parameters.T);

for sigma = sigma_range
    
    parameters.sigma = sigma;
    
    total_time_Kuramoto = 0;
    total_time_min = 0;
    
    count_successful = 0;  
    
    sum_error_functionvalues = 0;
    sum_final_error = 0;
    sum_error_hist = zeros(1,parameters.T);
    sum_iterations = 0;
    
    fprintf('\n sigma = %.4f\n ******* \n', sigma) 
    
    tic;
    for i = 1:runs
        
        X = Generate_Points.RandomlyChosen(M, d, ds, Nsp, noise, MOutliers);
        X = bsxfun(@minus, X, mean(X,2));
        
        parametersEnergy = struct;
        parametersEnergy.p1 = X;
        parametersEnergy.p2 = p;                                    % parameter p (Exponent)
        parametersEnergy.p3 = delta;                                % parameter delta (Perturbation)
        
        % compute argmin and corresponding function value
        t_start_min = tic;
        Vmin = ComputeMinimum(X);
        Emin = energy_functional(Vmin,parametersEnergy);
        time_min = toc(t_start_min);
        total_time_min = total_time_min + time_min;
        
        % auxilary
        parameters.Recon = @Reconstruct;
        parameters.Error = @ComputeError;
        parameters.trueSol = Vmin;
        
        % KV-CBO
        t_start_Kuramoto = tic;      
        [Valpha, Iter, time, Variance, Error, Consensus] = KuramotoVicsekMethod(energy_functional, parametersEnergy, parameters);        
        Ealpha = energy_functional(Valpha,parametersEnergy);
        time_Kuramoto = toc(t_start_Kuramoto);      
        total_time_Kuramoto = total_time_Kuramoto + time_Kuramoto;
        
        % consensus
        count_consensus(1, (sigma_range==sigma)) = count_consensus(1, (sigma_range==sigma)) + Consensus;
        if Consensus
            Consensus = 'Yes';
        else
            Consensus = 'No';
        end
        
        % final error
        final_error = Error(Iter);
        if final_error < success_constant
            count_successful = count_successful + 1;
        end
        
        Error(Iter:parameters.T) = Error(Iter);
        sum_error_hist = sum_error_hist + Error;
        sum_final_error = sum_final_error + final_error;
        
        error_functionvalues = abs(Ealpha-Emin);
        sum_error_functionvalues = sum_error_functionvalues + error_functionvalues;
        
        sum_iterations = sum_iterations + Iter;
        
        fprintf(' i = %i, consensus = %s, final error = %.2e, iterations = %i\n', i, Consensus, final_error, Iter);
        
    end
    time_runs = toc;
    
    srateSigma(1, (sigma_range==sigma)) = count_successful/runs;
    average_error((sigma_range==sigma), :) = sum_error_hist./runs;
    
    summary = [summary; ...
        [sigma, runs, count_consensus(1, (sigma_range==sigma)), sum_final_error/runs, sum_iterations/runs, time_runs/runs]];
end

% Plotting
plotAverageError(average_error, parameters.T, d, p, delta, runs, parameters.alpha, parameters.N, ...
    parameters.lambda, parameters.dt, parameters.epsilon, sigma_range)

plotSuccessRate(srateSigma, sigma_range, d, p, delta, runs, parameters.alpha, parameters.N, ...
    parameters.lambda, parameters.T, parameters.dt, parameters.epsilon);

%% Output File: Summary
TableSummary = array2table(round(summary,16));
TableSummary.Properties.VariableNames = {'sigma' 'runs' 'consensus' 'average_error' 'iterations_per_run' 'seconds_per_run'};          
% fname = sprintf('%s', 'summary.txt');
% writetable(TableSummary, fname, 'WriteRowNames',true, 'Delimiter',';') 
TableSummary

%%
function plotAverageError(average_error, T, d, p, delta, runs, alpha, N, lambda, dt, epsilon, sigma_range)

    figure('Position', [0 100 800 500])
    for j = 1:size(average_error,1)
        hold on
        % semilogy(1:T, average_error(j,:));
        semilogy(1:T, smoothdata(smoothdata(average_error(j,:))));
        set(gca, 'YScale', 'log')
        ylabel('Average Error');
        xlabel('Time Steps');  
    end
    legendCell = cellstr(num2str(sigma_range', '$\\sigma$=%.2f'));
    legend(legendCell);
    print -depsc AverageErrorSigma
    
    % fname = sprintf('%s', 'AverageError.fig');
    % savefig(fname)
    
    title({'Kuramoto-Vicsek Minimizer'; 
          sprintf('Dimension = %d, N=%i, p=%.2f, $\\delta$ = %.2e, $\\alpha$ = %.2e, $\\lambda $ = %i', d, N, p, delta, alpha, lambda);
          sprintf('Runs = %i, T=%.2e, dt = %.4f, epsilon = %.2e', runs, T, dt, epsilon); 
          },'interpreter','latex') 
    % print -depsc AverageErrorSigmaHelp
    hold off
end

function plotSuccessRate(srateSigma, sigma_range, d, p, delta, runs, alpha, N, ...
    lambda, T, dt, epsilon)

   sigmamin = min(sigma_range); 
   sigmamax = max(sigma_range);
   
   figure('Position', [0 100 800 500])
   plot(sigma_range, 100*srateSigma, '-o')
   axis([sigmamin sigmamax 0 110])
   xlabel('$\sigma$', 'Interpreter','latex');
   yticks([0 20 40 60 80 100])
   yticklabels({'0\%', '20\%', '40\%', '60\%', '80\%', '100\%'});
   ylabel('Success Rate');

   % fnameSucc = sprintf('%s', 'SuccessRatio.fig');
   % savefig(fnameSucc)
   
   print -depsc SuccessRateSigma
   title({'Success rate';
       sprintf('Dimension = %i, N = %i, p=%.2f, $\\delta$ = %.2e, $\\alpha$ = %.2e, $\\lambda $ = %i' , d, N, p, delta, alpha, lambda);
       sprintf('Runs = %i, T = %.2e, dt = %.4f, epsilon = %.2e', runs, T, dt, epsilon);
       },'interpreter','latex')
   % print -depsc SuccessRateSigmaHelp

end


function Vmin = ComputeMinimum(X)

    A = X;
    [Vg,D] = eig(A*A');
    [~,i] = max(diag(D));
    Vmin = Vg(:,i);
    
end

function v = Reconstruct(Valpha, varargin)
  v = Valpha;
end

function error = ComputeError(Valpha, Vmin)
  error = min([norm(Valpha-Vmin,2), norm(Valpha+Vmin,2)]);
end

function sigma_range = setSigma(d)
  switch d
      case 3
          sigma_range = 0.8;
      case 5
          sigma_range = 0.5;
      case 10
          sigma_range = 0.4;
      case 20
          sigma_range = 0.25;
      case 100
          sigma_range = 0.11;
      case 200
          sigma_range = 0.08;
      case 1000 
          sigma_range = 0.016;
      case 2000
          sigma_range = 0.012;
      case 2880
          sigma_range = 0.019;
  end

end

