clear; clc; close all;

d = 10;                                                     % Dimension
C = 1e-2;                                                   % success constant
runs = 5;                                                  % number of runs
verbose = 1;

% Parameters for Energy
energy_functional = @Energy_Class.RobustSubspaceDetection;    
p = 1;
delta = 1e-7;

%% Parameters for KV-CBO method
parameters = struct;
parameters.alpha = 1e15;
parameters.alphamax = 1e15;                                % comment this ligne out to have a constant alpha
parameters.mode = 2;                                       % 1 = isotropic, 2 = anisotropic
parameters.sigma = 2;                                      % initial sigma, sigma = 0 is the deterministic Kuramoto-Vicsek model
parameters.lambda = 1;
parameters.dt = 0.25;          
parameters.N = 100;                                       % number of particles
parameters.N2 = parameters.N;                              % number of particles to be evolved (randomly chosen)
parameters.N3 = parameters.N;                              % number of particles to compute Valpha (randomly chosen)  
parameters.d = d;
parameters.verbose = 0;

% Implementation parameters
parameters.T = 1000;                                       % maximal number of iterations
parameters.time_limit = 10;                                % time limit in seconds
parameters.epsilon = 1e-5;                                 % for stopping condition
parameters.mu = 1;                                         % parameter mu to drop particles
parameters.Nmin = 100;                                     % minimal number of particles
parameters.tau = 1.2; parameters.eta = 2;                  % parameters to adaptively change the sigma
parameters.l = 25;                                         % particles, sigma and alpha are updated every l-th iteration

%%
% Parameters for Point Cloud
Nsp = 25;           % number of subspaces
M = 100;            % number of points in each subspace
ds = 1;             % dimension of each subspace
noise = 0.01;       % Gaussian noise
MOutliers = 0;

% Numerical Comparison of KV-CBO and a benchmark method
% auxiliary variables
n_KV_leq_benchmark = 0;
n_KV_gt_benchmark = 0;
n_rel_error_leq_C = 0;

list_abserr_KV_leq_benchmar = [];
list_relerr_KV_leq_benchmark = [];

list_abserr_KV_gt_benchmark = [];
list_relerr_KV_gt_benchmark = [];

for i = 1:runs
    
    % Generate Points
    X = Generate_Points.NearlyParallel(M, d, ds, Nsp, noise, MOutliers);
    % X = Generate_Points.RandomlyChosen(M, d, ds, Nsp, noise, MOutliers);
    X = bsxfun(@minus, X, mean(X,2));  
    
    parametersEnergy = struct;
    parametersEnergy.p1 = X;
    parametersEnergy.p2 = p;                                    % parameter p (Exponent)
    parametersEnergy.p3 = delta;                                % parameter delta (Perturbation)
    
    %% Compute minimum with the benchmark method
    cd('Benchmark')
    options=struct;
    options.scaleopt='normal';                                  % normal or log
    options.p=p;                                                % 0<p<2
    options.initopt='random';                                   % random or pca
    options.svdopt='normal';                                    % normal or randomized
    options.maxiter=100;                                        % default
    options.epsilon=1e-10;         
    V_benchmark = fms(X',1,options);                            % second argument: dimension of subspce to find
    cd ..    
    
    %% KV-CBO method
    [Valpha, Iter] = KuramotoVicsekMethod(energy_functional, parametersEnergy, parameters);
    
    %% Comparison
    E_KV = energy_functional(Valpha,parametersEnergy);
    E_benchmark = energy_functional(V_benchmark,parametersEnergy);
    
    abs_error = norm(E_KV - E_benchmark);
    rel_error = abs_error/min(E_KV, E_benchmark);
    
    if E_KV <= E_benchmark
        n_KV_leq_benchmark = n_KV_leq_benchmark + 1;
        list_abserr_KV_leq_benchmar = [list_abserr_KV_leq_benchmar abs_error];
        list_relerr_KV_leq_benchmark = [list_relerr_KV_leq_benchmark rel_error];
    else
        n_KV_gt_benchmark = n_KV_gt_benchmark + 1; 
        list_abserr_KV_gt_benchmark = [list_abserr_KV_gt_benchmark abs_error];
        list_relerr_KV_gt_benchmark = [list_relerr_KV_gt_benchmark rel_error];
    end
    
    if rel_error <= C
       n_rel_error_leq_C = n_rel_error_leq_C + 1;
    end
    
    if verbose == 1
        msg = sprintf([' Runs \t \t \t \t %i\n', ...
                       ' *****************\n', ...
                       ' Relative Error <= C: \t \t %.2f\n', ...
                       ' *****************\n', ...
                       ' Rate: \t \t \t \t %.2f\n', ...
                       ' Absolute Error: \t \t %.2e\n', ...
                       ' Relative Error: \t \t %.2e\n', ...
                       ' *****************\n', ...
                       ' Rate: \t \t \t \t %.2f\n', ...
                       ' Absolute Error: \t \t %.2e\n', ...
                       ' Relative Error: \t \t %.2e\n'], ...
                               i, ...
                               n_rel_error_leq_C/i, ...
                               n_KV_leq_benchmark/i, ...
                               sum(list_abserr_KV_leq_benchmar)/n_KV_leq_benchmark, ...
                               sum(list_relerr_KV_leq_benchmark)/n_KV_leq_benchmark, ...
                               n_KV_gt_benchmark/i, ...
                               sum(list_abserr_KV_gt_benchmark)/n_KV_gt_benchmark, ...
                               sum(list_relerr_KV_gt_benchmark)/n_KV_gt_benchmark);

                reverseStr = repmat(sprintf('\b'), 1, length(msg));
                fprintf([reverseStr, msg]);
        
    end
    
end

if ~verbose
    disp('*******************')
    fprintf(' Relative Error <= C: \t \t %.2f\n', n_rel_error_leq_C/runs)
    disp('*******************')
    fprintf(' Rate: \t \t \t \t %.2f\n', n_KV_leq_benchmark/runs)
    fprintf(' Absolute Error: \t \t %.2e\n', sum(list_abserr_KV_leq_benchmar)/n_KV_leq_benchmark)
    fprintf(' Relative Error: \t \t %.2e\n', sum(list_relerr_KV_leq_benchmark)/n_KV_leq_benchmark)
    disp('*******************')
    fprintf(' Rate: \t \t \t \t %.2f\n', n_KV_gt_benchmark/runs)
    fprintf(' Absolute Error: \t \t %.2e\n', sum(list_abserr_KV_gt_benchmark)/n_KV_gt_benchmark)
    fprintf(' Relative Error: \t \t %.2e\n', sum(list_relerr_KV_gt_benchmark)/n_KV_gt_benchmark)
end
