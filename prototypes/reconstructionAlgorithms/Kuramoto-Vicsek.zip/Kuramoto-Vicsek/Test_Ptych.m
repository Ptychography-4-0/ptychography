clear; clc; close all;

set(0,'DefaultTextInterpreter','latex')
set(0,'DefaultLegendInterpreter','latex')
set(0,'DefaultAxesTickLabelInterpreter','latex')
set(0,'DefaultLegendFontSize',20)
set(0,'DefaultTextFontSize',20)
set(0,'DefaultAxesFontSize',16)
set(0,'DefaultLineLineWidth',2)

%% Set up of problem
A = imread(sprintf('Smiley4.png'));
% A = rgb2gray(A);

n = size(A,1); 

% normalize image
A = reshape(double(A),n*n,1);
A = (A-min(A))/(max(A)-min(A));
A = reshape(A,n,n);

Ahat = fft2(A);
F = abs(fftshift(Ahat));        
F = log(F+1);                   
F = mat2gray(F);

figure
subplot(1,3,1)
imshow(A)
title('Original Image')
subplot(1,3,2)
imshow(F, []) 
title('Fourier Transform')

%% Parameters for phase retrieval
d = n*n;                                                        % dimension
M = 16*d;                                                       % number of frame vectors

% Frame: uniform on the sphere
% X = Generate_Points.UniformOnSphere(d, M);                    % columns of X form a frame
% A = LowerFrameBound(X);                                       % optimal lower frame bound

frameVec = 'Fourier';                                           % 'Gaussian';
 
if strcmp(frameVec, 'Gaussian')
  X = randn(d,M) + 1j*randn(d,M); 
  X = X./vecnorm(X);
elseif strcmp(frameVec, 'Fourier')
  X = [];   % dftmtx(M);
  a = sqrt(M/d);
  
  A = [A; zeros((a-1)*n, n)];
  A = [A zeros(a*n,(a-1)*n)];
end

Y = reshape(abs(fftshift(fft2(A))).^2, M, 1);                   % Measurements
C = norm(double(reshape(A(1:n,1:n),d,1)));                      % TODO: Later compute C with the lower frame bound % sqrt(norm(Y,1)/A); 

parameters = struct;
parameters.trueSol = reshape(A(1:n,1:n),d,1); 
parameters.Guess = reshape(parameters.trueSol/C, d, 1);       % Cheating: assume guess of the solution is known (sample initial particles close to this guess, von-Mises-Fisher distribution) 
% parameters.Supp = [14; 19; 23; 31; 39; 43; 47; 54];             % Cheating: assume the support is known 
parameters.Recon = @Reconstruct;
parameters.Error = @ComputeError;                               % Peak Signal-to-Noise Ratio  

energy_functional = @Energy_Class.Ptych; 

parametersEnergy = struct;
parametersEnergy.p1 = X;
parametersEnergy.p2 = C;
parametersEnergy.p3 = Y;

%% consistency check
check = energy_functional(reshape(parameters.trueSol/C, d, 1), parametersEnergy) < 1e-10;
if ~check
   disp('*** Consistency check failed ***') 
end

%% Parameters for KV-CBO method
parameters.alpha = 1e15;
parameters.mode = 1;                                       % 1 = isotropic, 2 = anisotropic
parameters.sigma = 0.13;                                    % initial sigma, sigma = 0 is the deterministic Kuramoto-Vicsek model
parameters.lambda = 1;
parameters.dt = 0.01;          
parameters.N = 1000;                                         % number of particles
parameters.N2 = parameters.N;                               % number of particles to be evolved (randomly chosen)
parameters.N3 = parameters.N;                               % number of particles to compute Valpha (randomly chosen)
parameters.d = d;
parameters.verbose = 1;

% Implementation parameters
parameters.T = 1000;                                        % maximal number of iterations
parameters.epsilon = 1e-12;                                 % for stopping condition
parameters.mu = 1;                                          % parameter mu to drop particles
parameters.Nmin = 500;                                      % minimal number of particles
parameters.tau = 1.2; parameters.eta = 2;                   % parameters to adaptively change the sigma
parameters.l = 25;                                          % particles, sigma and alpha are updated every l-th iteration

%% KV-CBO method 
[Valpha, Iter, time, Variance, PSNR, ~, F] = KuramotoVicsekMethod(energy_functional, parametersEnergy, parameters);

fprintf('\n Runtime: \t \t %.2f\n', Iter*time);

% %% Video
% writerObj = VideoWriter(sprintf('%s','Video_Smiley'),'MPEG-4');
% writerObj.FrameRate = 250;
% open(writerObj);
% for i = 1:length(F)
%     frame = F(i);
%     writeVideo(writerObj, frame);
% end
% close(writerObj);

%% Plot empirical variance and error
figure
semilogy(1:Iter, PSNR(1:Iter))
set(gca, 'YScale', 'log')
ax = gca;
ax.YColor = [0, 0.4470, 0.7410];
ylabel('Peak Signal-to-Noise Ratio')
title({'KV-CBO method'; 'Peak Signal-to-Noise Ratio and Variance'})
hold on
yyaxis right
ax = gca;
ax.YColor = [0.25, 0.25, 0.25];
semilogy(1:Iter,Variance(1:Iter))
set(gca, 'YScale', 'log')
ylabel('Variance')
legend('Peak Signal-to-Noise Ratio', 'Variance', 'location', 'southeast')
xlabel('Time Steps')
axis([0 Iter min(Variance(1:Iter)) max(Variance(1:Iter))])
box off

function v = Reconstruct(Valpha, parametersEnergy)
  persistent i
  if isempty(i)
        i = 0;
  end
  i = i + 1;

  C = parametersEnergy.p2;
  v = C*Valpha(:,1);
  
  if mod(i,25) == 0 
      n = sqrt(size(v,1));
      vtmp = reshape(v, n, n);
      subplot(1,3,3)
      imshow(vtmp)
      title('Reconstructed Image')
      drawnow
  end
  
end

function [error, str] = ComputeError(Valpha, Vmin)
  error = psnr(Valpha, Vmin);
  str = 'Peak Signal-to-Noise: \t';
end
