clear; clc; close all;

set(0,'DefaultTextInterpreter','latex')
set(0,'DefaultLegendInterpreter','latex')
set(0,'DefaultAxesTickLabelInterpreter','latex')
set(0,'DefaultLegendFontSize',20)
set(0,'DefaultTextFontSize',20)
set(0,'DefaultAxesFontSize',16)
set(0,'DefaultLineLineWidth',2);

% Visualization of KV-CBO for Ackley and Rastrigin function in 1D

d = 1;                                          % dimension (fixed)

%% Energy functional
energy_functional = @Energy_Class.Ackley;
parametersEnergy = struct;
parametersEnergy.p1 = -20;
parametersEnergy.p2 = -0.2;                                    
parametersEnergy.p3 = 20;                                    
parametersEnergy.p4 = pi/2;                                 % x coordinate of global minimum   

% energy_functional = @Energy_Class.Rastrigin;
% parametersEnergy = struct;
% parametersEnergy.p1 = 0;
% parametersEnergy.p2 = 10;                                    
% parametersEnergy.p3 = 10;                                    
% parametersEnergy.p4 = pi/2;                                 % x coordinate of global minimum   

%% Parameters for KV-CBO method
N = 5;                                                      % number of particles
N2 = 2;                                                     % number of particles to be evolved (randomly chosen)
N3 = N;                                                     % number of particles to compute Valpha (randomly chosen)
T = 40;                                                     % maximum number of iterations
dt = 0.2;                                                   % time step
sigma = 0.5;                                                % diffusion constant
alpha_KV = 100;                                             % alpha parameter
lambda = 1;                                                 % coupling constant
getVideo = 1;                                               % save output as video

pmin = parametersEnergy.p4;
Emin = energy_functional(pmin, parametersEnergy);
Vmin = HyperSphere(pmin);

% Deterministic grid for the half-circle
nn = 5000;
v = linspace(0,pi,nn);
V = HyperSphere(v);
E = energy_functional(v,parametersEnergy);

% Initial data 
Vp = RandHyperSphere(2,N,1);
vp = InvHyperSphere(Vp);
Ep = energy_functional(vp,parametersEnergy);

% Energy renormalization 
Em = min(Ep);
EM = max(Ep);
Ne = EM-Em;
Ep = (Ep-Em)/Ne;
EM = max(Ep);
E  = (E-Em)/Ne;

Valpha = sum((Vp.*exp(-alpha_KV*Ep))')';
NNalpha = norm(Valpha,2);

% Renormalization on the circle
Valpha = (Valpha/NNalpha);
valpha=InvHyperSphere(Valpha);
Ea = energy_functional(valpha,parametersEnergy);
Ea = (Ea-Em)/Ne;

Valpha=Valpha*ones(1,N);
GG(1)=sum(vecnorm(Vp-Valpha,2))/N;

figure
plot(v,E,'-b',vp,Ep,'or');
hold on;
Emin  = (Emin-Em)/Ne;
GG2(1)=sum(vecnorm(Vp-Vmin*ones(1,N),2))/N;
Ax = axis;
axis([0 pi Ax(3) Ax(4)]);
    
xlabel('$\theta$');
ylabel('$\mathcal{E}(\theta)$');
axis square
title('Renormalized energy and initial data')
hold off

disp('Press a key to start');
pause;

for t = 1:T
    
    Valpha = sum((Vp.*exp(-alpha_KV*Ep))')';
    NNalpha = vecnorm(Valpha,2);
    
    % Renormalization on the circle
    
    Valpha = Valpha/NNalpha;
    
    valpha=InvHyperSphere(Valpha);
    Ea = energy_functional(valpha,parametersEnergy);
    Ea = (Ea-Em)/Ne;

    % Vectorialization   
    Valpha = Valpha*ones(1,N);
    Salphi = ones(2,1)*sum(Valpha.*Vp);
    eta = randn(2,N);
    Setai = ones(2,1)*sum(eta.*Vp);
    Nalphi = ones(2,1)*vecnorm(Vp-Valpha,2);
    
    sgn = 1;
    norma = Nalphi;  
    
    diff = norma.*(eta-Setai.*Vp);
    coll = sgn.*(Valpha-Salphi.*Vp);
    coll2 = vecnorm(Vp-Valpha,2).^2.*Vp;
    
    % Updating the particles
    Vp = Vp + dt*lambda*coll - dt*(d-1)*coll2*(sigma.^2./2) + sqrt(dt).*diff*sigma; 
    Vp = Vp./vecnorm(Vp,2); 
    
    % This forces the vector to stay on the halph circle
    
    vp = InvHyperSphere(Vp);
    vp = mod(vp,pi);
    Vp = HyperSphere(vp);
    
    Ep = energy_functional(vp,parametersEnergy);
    Ep = (Ep-Em)/Ne; 
    plot(v,E,'-b',vp,Ep,'or');
    
    Ax = axis;
    axis([0 pi Ax(3) Ax(4)]);
    xlabel('$\theta$');
    ylabel('$\mathcal{E}(\theta)$');
    axis square
    
    xlabel('$v_x=\cos(\theta)$');
    ylabel('$v_y=\sin(\theta)$');
    hold off;
    drawnow;
    if getVideo
        F(t) = getframe(gcf) ;
    end
    pause(0.25);
end


if getVideo == 1
     
    writerObj = VideoWriter(sprintf('%s','Video_'),'MPEG-4');
    writerObj.FrameRate = 5;
    open(writerObj);
    
    for i=1:length(F)
        frame = F(i) ;
        writeVideo(writerObj, frame);
    end
    
    close(writerObj);
end
