%% Example script for running the FMS algorithm
%
% T Maunu 2014
clear; clc; close all;

d=1; % dimension of the subspace to fund
D=100; % dimension of points
N_in=200; % inliers
N_out=0; % outliers
N=N_in+N_out;
noise=1e-6;
options=struct;

options.scaleopt='normal';      %normal or log
options.p=1;                    %0<p<=1
options.initopt='random';          %random or pca
options.svdopt='normal';    %normal or randomized
options.maxiter=100;            %default
options.epsilon=10^-10;         %default

U = orth(randn(D,d));

inliers = randn(N_in,d) *  U'/sqrt(d);
outliers = randn(N_out,D)/sqrt(D) ;

inliers = inliers + sqrt(noise)*randn(N_in,D)/sqrt(D);
outliers = outliers + sqrt(noise)*randn(N_out,D)/sqrt(D);


X = [inliers;outliers];
L=fms(X,d,options);
calc_sdist(L,U)

[~,~,L2] = svd(X,'econ');
L2 = L2(:,1:d);
calc_sdist(L2,U)





