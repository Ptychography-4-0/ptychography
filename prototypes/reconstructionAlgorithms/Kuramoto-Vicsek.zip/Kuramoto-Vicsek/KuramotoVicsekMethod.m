function [Valpha, t, varargout] = KuramotoVicsekMethod(energy_functional, parametersEnergy, parameters)
    
    %% Set settings   
    if isfield(parameters,'d')
        d = parameters.d;
    end 
    if isfield(parameters,'alpha')
        alpha = parameters.alpha;
    end 
    if isfield(parameters,'alphamax')
        alphamax = parameters.alphamax;
        alpha_adaptive = 1;
    else
        alpha_adaptive = 0;
    end 
    if isfield(parameters,'sigma')
        sigma = parameters.sigma;
    end
    if isfield(parameters,'N')
        N = parameters.N;
    end
    if isfield(parameters,'N2')
        N2 = parameters.N2;
    end
    if isfield(parameters,'N3')
        N3 = parameters.N3;
    end
    if isfield(parameters,'Nmin')
        Nmin = parameters.Nmin;
    end
    if isfield(parameters,'T')
        T = parameters.T;
    end
    if isfield(parameters,'epsilon')
        epsilon = parameters.epsilon;
    end
    if isfield(parameters,'time_limit')
        time_limit = parameters.time_limit;
    end
    if isfield(parameters,'sigma')
        sigma = parameters.sigma;
    end
    if isfield(parameters,'lambda')
        lambda = parameters.lambda;
    end
    if isfield(parameters,'dt')
        dt = parameters.dt;
    end
    if isfield(parameters,'mu')
        mu = parameters.mu;
    end
    if isfield(parameters,'eta')
        eta = parameters.eta;
    end
    if isfield(parameters,'tau')
        tau = parameters.tau;
    end
    if isfield(parameters,'l')
        l = parameters.l;
    end
    if isfield(parameters,'trueSol')
        trueSol = parameters.trueSol;
        computeError = 1;
        Recon = parameters.Recon;
        CompErr = parameters.Error;
    else
        computeError = 0;
    end
    if isfield(parameters,'verbose')
        verbose = parameters.verbose;
    end
    if isfield(parameters,'Guess')
       Guess = parameters.Guess; 
       vmf = 1;
    else
       vmf = 0;
    end
    if isfield(parameters,'mode')
        mode = parameters.mode;
    end
    if isfield(parameters,'Supp')
        % Support of the image is known a-priori
        Supp = parameters.Supp;
        dd = size(Supp, 1);                                
    else
        % Support is not known
        Supp = [];
        dd = 0;
    end

    %% sKV method
    % Initial Data
    if and(vmf == 0, dd == 0)
        V = RandHyperSphere(d,N,1);                         % initial particles in euclidean coordinates 
    elseif and(vmf == 0, dd > 0)
        W = RandHyperSphere(dd,N,1); 
        V = zeros(d,N);
        V(Supp,:) = W;
    elseif vmf == 1
        % k small -> nearly uniform distribution on the sphere
        % k large -> concentrated distribution on the sphere
        % k = 1   -> uniform distribution
        k = 100; 
        V = randVMF(N, Guess, k)';                          % von-Mises-Fischer distribution
    end
    
    Ep = energy_functional(V, parametersEnergy);
        
    % Energy rescaling
    Em = min(Ep);
    Eminp = min(Ep);
    EMM = max(Ep);
    Ne = EMM-Em;
    Ep = (Ep-Em)/Ne;

    t = 1;
    Valpha = ComputeValpha(V, N, alpha, energy_functional, parametersEnergy);
    variance = sum(vecnorm(V-mean(V,2)*ones(1,size(V,2)),2).^2);  

    error_hist = zeros(1,T);
    variance_hist = zeros(1,T);
    avg_variance_hist = zeros(1,T);
    var_avg_variance_hist = zeros(1,T);
    stopping_criterion = sum(vecnorm(V-Valpha*ones(1,N),2))/N < epsilon;

    f = @() KuramotoIteration(d, Valpha, alpha, sigma, mode, lambda, dt, N, N2, N3, ...
                        V, Supp, energy_functional, parametersEnergy);
                
    while and(t <= T, ~stopping_criterion)

        [Valpha, V, Emint, Vmint] = KuramotoIteration(d, Valpha, alpha, sigma, mode, lambda, dt, N, N2, N3, ...
                        V, Supp, energy_functional, parametersEnergy);
                    
        % store particle with lowest energy so far
        if Emint <= Eminp
            Eminp = Emint;
            Vminp = Vmint;
        end
                    
         % discard particles every l-th iteration depending on change in variance
        [variance, I] = Variance(V, mu, Nmin, variance);
        variance_hist(t) = variance;
        avg_variance_hist(t) = sum(variance_hist)/t;
        var_avg_variance_hist(t) = var(avg_variance_hist(1:t));
        
        if computeError == 1
            r = Recon(Valpha, parametersEnergy);
            error_hist(t) = CompErr(r, trueSol);
            % F(t) = getframe(gcf);
        end
        
        if mod(t,l) == 0
            if var_avg_variance_hist(t) < eta
                sigma = sigma./tau;
            end
            if alpha_adaptive == 1
                alpha = min(2*alpha,alphamax);
            end
            if verbose == 1
                r = Recon(Valpha, parametersEnergy);
                [error, str] = CompErr(r, trueSol);
                consensus = sum(vecnorm(V-Valpha*ones(1,N),2))/N;
                
                msg = sprintf([' Iterations: \t \t %i\n', ...
                               ' max. Iterations: \t %i\n\n', ...
                               ' Variance: \t \t %.2e\n', ...
                               ' Consensus: \t \t %.2e\n', ...
                               ' %s %.2e\n\n', ...
                               ' Number of Particles: \t %i'] ...
                               , t, T, variance, consensus, str, error, N);

                reverseStr = repmat(sprintf('\b'), 1, length(msg));
                fprintf([reverseStr, msg]);
            end
            V(:,I) = [];
            Ep(:,I) = [];
            N = size(V,2);
        end

        stopping_criterion = sum(vecnorm(V-Valpha*ones(1,N),2))/N < epsilon;
        t = t + 1;
    end
    t = t - 1;
    
%     Ea = energy_functional(Valpha, parametersEnergy);
%     if and(Eminp < Ea, min([norm(Valpha - Vminp) norm(Valpha + Vminp)]) > 1e-4)
%         fprintf('\n\n ********************************** \n\n')
%         fprintf(' Vminp has lower energy than Valpha.')
%         fprintf('\n\n ********************************** \n\n')
%     end
 
    varargout{1} = timeit(f);               % median runtime per call of KuramotoIteration
    varargout{2} = variance_hist;
    varargout{3} = error_hist;
    varargout{4} = stopping_criterion;
    % varargout{5} = F;
    % varargout{6} = Vminp;

end
