function [Valpha, V, Emin, Vmin] = KuramotoIteration(d, Valpha, alpha, sigma, mode, lambda, dt, N, N2, N3, ...
                        V, Supp, energy_functional, parametersEnergy)

     % evolve only few randomly choosen particles
     if N > N2
         sp = randperm(N,N2);
         V2 = V(:,sp);
     else
         N2 = N;
         V2 = V;
     end
     
     if isempty(Supp) == 1
        dd = d;
     else
        % TODO: das muss nicht in jeder Iteration gemacht werden
        dd = size(Supp,1);
        J = 1:d;
        J(ismember(J,Supp)) = [];
        V2(J,:) = [];
        Valpha(J,:) = [];
     end
      
     if mode == 1
               
         % Vectorialization
         Nalphi = ones(dd,1)*vecnorm(V2-Valpha*ones(1,N2),2);
         sgn = 1;
         eta = randn(dd,N2);
         Valpha = Valpha*ones(1,N2);
         
         % Coefficients
         diff = Nalphi.*(eta-ones(dd,1)*sum(eta.*V2).*V2);
         coll = sgn.*(Valpha-ones(dd,1)*sum(Valpha.*V2).*V2);
         coll2 = vecnorm(V2-Valpha,2).^2.*V2;
         
         % Updating the particles
         V2 = V2 + dt*lambda*coll - dt*(dd-1)*coll2*(sigma.^2./2) + sqrt(dt).*diff*sigma;
         V2 = V2./vecnorm(V2,2);
                
     elseif mode == 2 % anisotropic noise
         
         % Vectorization
         eta = randn(dd,N2);
         Valpha = Valpha*ones(1,N2);
         
         % Coefficients
         coll = (Valpha-ones(dd,1)*sum(Valpha.*V2).*V2);         
         D = V2-Valpha;
         tau = D.*eta;
         diff = (tau-ones(dd,1)*sum(tau.*V2).*V2);
         coll2 = (D.^2 + vecnorm(D,2).^2 - 2*vecnorm(D.*V2).^2).*V2;
         
         % Updating the particles
         V2 = V2 + dt*lambda*coll - dt*coll2*(sigma.^2./2) + sqrt(dt).*diff.*sigma;
         V2 = V2./vecnorm(V2,2);
     end
     
      if isempty(Supp) ~= 1
          W = zeros(d,N2);
          W(Supp,:) = V2;
          V2 = W;
      end
      
     if N > N2
        V(:,sp) = V2;
     else
        V = V2; 
     end
     
     [Valpha, Emin, Vmin] = ComputeValpha(V, N3, alpha, energy_functional, parametersEnergy);
      
end
    