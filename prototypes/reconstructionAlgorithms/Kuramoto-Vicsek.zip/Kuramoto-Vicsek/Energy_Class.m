classdef Energy_Class
    
    methods (Static)
        
        function E = Ackley(V, parametersEnergy) 
            A = parametersEnergy.p1;
            B = parametersEnergy.p2;
            C = parametersEnergy.p3;
            D = parametersEnergy.p4;
            
            [d,~] = size(V);
            x = 3*(V - D);
            
            if d > 2
                a = vecnorm(x,2)/sqrt(d);
                b = mean(cos(2*pi*(x)));
            else
                a = abs(x)/sqrt(d);
                b = cos(2*pi*(x))/(d);
            end
            
            E = A*exp(B*a)-exp(b)+exp(1)+C;
        end
        
        function E = Rastrigin(V, parametersEnergy)
            A = parametersEnergy.p1;
            B = parametersEnergy.p2;
            C = parametersEnergy.p3;
            D = parametersEnergy.p4;
            
            [d,~]=size(V);
            x = 3*(V - D);
            
            if d > 2
                a = mean(x.^2);
                b = mean(cos(2*pi*(x)));
            else
                a = abs(x).^2/(d);
                b = cos(2*pi*(x))/d;
            end
            
            E = a - B*b + C;
        end
        
        function E = RobustSubspaceDetection(V,parametersEnergy)
            X = parametersEnergy.p1;
            p = parametersEnergy.p2;
            delta = parametersEnergy.p3;
            
            nn = size(V,2);
            XN = ones(nn,1)*vecnorm(X,2);
            XV = V'*X;
            Z = XN.*XN-XV.*XV;                  % We use the identity||x - <x,v> v ||^2 = ||x||^2 - <x,v>^2
            Z = Z + (delta^2)*ones(size(Z));    % delta = perturbation parameter (for p < 2)
            E = sum((Z)'.^(p/2));
        end
        
        function E = PhaseRetrieval(V,parametersEnergy) 
            X = parametersEnergy.p1;
            C = parametersEnergy.p2;
            Y = parametersEnergy.p3;
            
            nn = size(V,2);            
            Y = Y./(C*C);
            
            XV = V'*X;  
                        
            % Objective function
            Z = (abs(XV.*XV) - ones(nn,1)*Y').^2;
            E = sum(Z');
        end
        
        function E = Ptych(V,parametersEnergy) 
            X = parametersEnergy.p1;
            C = parametersEnergy.p2;
            Y = parametersEnergy.p3;                     
            Y = Y./(C*C);
            
            d = size(V,1);
            N = size(V,2);             
            M = size(Y,1);
            n = sqrt(d);
                        
            Vhat2 = zeros(M, N);
            
            for i = 1:N
               Vi = reshape(V(:,i), n, n);
               
               a = sqrt(M/d);
               Vi = [Vi; zeros((a-1)*n, n)];
               Vi = [Vi zeros(a*n,(a-1)*n)];
               
               Vhat2(:,i) = reshape(abs(fftshift(fft2(Vi))).^2, M, 1);
            end
            
            Z = (Vhat2 - Y*ones(1,N)).^2;
            E = sum(Z);
        end
        
    end
end

