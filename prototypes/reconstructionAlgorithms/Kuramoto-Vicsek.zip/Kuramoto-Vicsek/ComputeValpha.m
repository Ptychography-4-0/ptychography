function [Valpha, Esmin, Vsmin] = ComputeValpha(V, N3, alpha, energy_functional, parametersEnergy)
   N = size(V,2);

    if N3 < N
        % choose a random subset of the particles
        sp = randperm(N,N3);
        Vs = V(:,sp);
    else
        Vs = V;
    end
    
    Es = energy_functional(Vs, parametersEnergy);   
    
    [Esmin, i] = min(Es);    
    Valpha = sum((Vs.*exp(-alpha*(Es-Esmin))),2);
    Valpha = Valpha/sum(exp(-alpha*(Es-Esmin)));
    
    Vsmin = Vs(:,i);    % particle with the lowest energy in this iteration
end
